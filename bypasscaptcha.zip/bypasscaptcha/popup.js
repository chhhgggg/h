(() => {
    'use strict';
  
    async function updateSetting(element) {
      let newValue = element.classList.contains("settings_toggle") ? true : parseInt(element.value);
      await chrome.storage.local.set({ [element.dataset.settings]: newValue });
      if (element.classList.contains("settings_toggle")) {
        element.classList.remove("on", "off");
        element.classList.add(newValue ? "on" : "off");
      }
    }
  
    function initializeSettings() {
      const toggles = document.getElementsByClassName("settings_toggle");
      const inputs = document.getElementsByClassName("settings_text");
      
      chrome.storage.local.get(null, async (settings) => {
        for (const toggle of toggles) {
          const settingKey = toggle.dataset.settings;
          let currentValue = settings[settingKey] ?? true; // Auto bật
          
          await chrome.storage.local.set({ [settingKey]: currentValue });
          toggle.classList.remove("on", "off");
          toggle.classList.add(currentValue ? "on" : "off");
          toggle.addEventListener("click", () => updateSetting(toggle));
        }
        
        for (const input of inputs) {
          const settingKey = input.dataset.settings;
          input.value = settings[settingKey] ?? "1";
          input.addEventListener("input", () => updateSetting(input));
        }
      });
    }
  
    document.addEventListener("DOMContentLoaded", initializeSettings);
  })();
  