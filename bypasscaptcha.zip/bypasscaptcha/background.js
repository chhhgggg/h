(() => {
    'use strict';
  
    const _0x929848 = {
      'recaptcha_auto_open': true,
      'recaptcha_auto_solve': true,
      'recaptcha_click_delay_time': 0x12c,
      'recaptcha_solve_delay_time': 10
    };
    chrome.runtime.onInstalled.addListener(async () => {
      for (const [_0x2f7ce3, _0x2e6a48] of Object.entries(_0x929848)) {
        const _0x72d2fe = await chrome.storage.local.get(_0x2f7ce3);
        console.log(_0x72d2fe);
        if (undefined === _0x72d2fe[_0x2f7ce3]) {
          await chrome.storage.local.set({
            [_0x2f7ce3]: _0x2e6a48
          });
        }
      }
      const _0x2bedb3 = chrome.runtime.getURL('').startsWith("moz");
      const _0x27d986 = await chrome.permissions.contains({
        'origins': ["<all_urls>", "*://*.google.com/recaptcha/*", "*://*.recaptcha.net/recaptcha/*"]
      });
      if (_0x2bedb3 && !_0x27d986) {
        chrome.tabs.create({
          'url': chrome.runtime.getURL("setup.html")
        });
      }
    });
    const _0x11a17a = {};
    chrome.runtime.onMessage.addListener(function ({
      type: _0x2204a7,
      label: _0x55cdde
    }, _0xdb9f97, _0x502bc7) {
      (async () => {
        if ("KV_SET" === _0x2204a7) {
          if (_0x55cdde.tab_specific) {
            _0x55cdde.key = _0xdb9f97.tab.id + '_' + _0x55cdde.key;
          }
          _0x11a17a[_0x55cdde.key] = _0x55cdde.value;
          _0x502bc7({
            'status': "success"
          });
        } else if ("KV_GET" === _0x2204a7) {
          if (_0x55cdde.tab_specific) {
            _0x55cdde.key = _0xdb9f97.tab.id + '_' + _0x55cdde.key;
          }
          _0x502bc7({
            'status': "success",
            'value': _0x11a17a[_0x55cdde.key]
          });
        }
      })();
      return true;
    });
  })();