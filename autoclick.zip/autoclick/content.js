// Lấy tọa độ trung tâm cửa sổ
function getWindowCenter() {
    const width = window.innerWidth;
    const height = window.innerHeight;
    return {
        x: Math.floor(width / 2),
        y: Math.floor(height / 2),
        width: width,
        height: height
    };
}

// Thực hiện triple double-click tại tọa độ
function tripleDoubleClickAtCenter() {
    const center = getWindowCenter();
    const element = document.elementFromPoint(center.x, center.y);
    console.log("Phần tử tại trung tâm:", element);

    function doubleClick(x, y) {
        if (element) {
            // Mô phỏng 2 click đơn để thay thế double-click nếu cần
            const clickEvent = new MouseEvent('click', {
                bubbles: true,
                cancelable: true,
                view: window,
                clientX: x,
                clientY: y
            });
            element.dispatchEvent(clickEvent);
            setTimeout(() => element.dispatchEvent(clickEvent), 100); // 100ms giữa 2 click
            
            // Hoặc dùng sự kiện dblclick trực tiếp
            const dblClickEvent = new MouseEvent('dblclick', {
                bubbles: true,
                cancelable: true,
                view: window,
                clientX: x,
                clientY: y
            });
            element.dispatchEvent(dblClickEvent);
        }
    }

    console.log(`Thực hiện 3 lần double-click tại trung tâm (${center.x}, ${center.y})`);
    doubleClick(center.x, center.y);
    setTimeout(() => doubleClick(center.x, center.y), 500); // Tăng delay lên 500ms
    setTimeout(() => doubleClick(center.x, center.y), 1000);
}

// Tự động click nút Follow nếu có
function clickFollowIfAvailable() {
    const followBtn = document.querySelector(
        '#main-content-others_homepage > div > div.e1457k4r14.css-cooqqt-DivShareLayoutHeader-StyledDivShareLayoutHeaderV2-CreatorPageHeader.e13xij562 > div.css-1o9t6sm-DivShareTitleContainer-CreatorPageHeaderShareContainer.e1457k4r15 > div.css-12aeehi-DivButtonPanelWrapper.efrkfhz0 > div > button > div > div'
    );

    if (followBtn) {
        const text = followBtn.textContent?.trim().toLowerCase() || '';
        if (text.includes('follow')) {
            followBtn.click();
            console.log("Đã click nút Follow");
        } else {
            console.log("Đã Follow rồi hoặc nút không khả dụng (text:", text, ")");
        }
    } else {
        console.log("Không tìm thấy nút Follow");
    }
}

// Tự động click Follow và triple double-click định kỳ
function autoClickFollowAndLike(interval = 2000) {
    let lastCenter = getWindowCenter();

    setInterval(() => {
        const currentCenter = getWindowCenter();

        // Kiểm tra nếu kích thước cửa sổ thay đổi
        if (currentCenter.width !== lastCenter.width || currentCenter.height !== lastCenter.height) {
            console.log(`Kích thước cửa sổ thay đổi: ${currentCenter.width}x${currentCenter.height}`);
            lastCenter = currentCenter;
        }

        console.log("Đang thử click Follow và triple double-click tại trung tâm...");
        clickFollowIfAvailable();
        tripleDoubleClickAtCenter();
    }, interval);
}

// Khởi động sau khi trang load
window.addEventListener('load', () => {
    setTimeout(() => {
        console.log("Bắt đầu auto click Follow và triple double-click vô tận...");
        autoClickFollowAndLike();
    }, 3000);
});

// Theo dõi khi cửa sổ resize
window.addEventListener('resize', () => {
    const center = getWindowCenter();
    console.log(`Cửa sổ resize - Tọa độ trung tâm mới: (${center.x}, ${center.y})`);
});